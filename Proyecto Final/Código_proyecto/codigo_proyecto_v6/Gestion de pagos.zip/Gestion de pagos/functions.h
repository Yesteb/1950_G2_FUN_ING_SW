//functions.h
#include "functions.c"

void historialPagos();

void IniciarSesion();

void RegistroPadreFamilia();

void RegistrarPagos();

void buscarRepresentante();

void buscarPagoApellido();

void buscarPagoID();

void modificarPadreFamilia();


