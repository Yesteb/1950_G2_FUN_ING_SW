//functions.h
#include "functions.c"

void imprimirArchivo();

void IniciarSesion();

void RegistroPadreFamilia();

void RegistrarPagos();

void modificarPadreFamilia();


